# CS 4480 PA3 Network Management Automation

This project sets up the 4 node, 2 host topology as instructed in the PA3.pdf on canvas. It uses Docker containers and configures OSPF using FRRouting (FRR). 

# Included Files

- Brigham_Inkley_u0887324.py: The actual script itself. Can be run using sudo, or by already being in sudo bash (root)
- Dockerfile: How the routers are configured. To be run before certain parts of the script. See below on exact instructions
- README.md: The file you are reading right now!

# Instructions

All instructions assume you are already on root (sudo bash)

When starting, go in this order:
	1 - python3 Brigham_Inkley_u0887324.py --build-topology (In the directory where Brigham_Inkley_u0887324.py lives)
	2 - docker build -t frrouting/frr-custom . (Make sure you are in the directory where the Dockerfile lives)
	2b (optional) - docker images | grep frr-custom (Checks that the docker images are working)
	3 - python3 Brigham_Inkley_u0887324.py --start-ospf
	4 - python3 Brigham_Inkley_u0887324.py --install-routes
	5 - python3 Brigham_Inkley_u0887324.py --move-traffic north OR python3 Brigham_Inkley_u0887324.py --move-traffic south

Following this pattern should get you working all the way with this orchestrator script. 
